    <div id="templatemo_footer">
    	<p><a href="index.php">Home</a> | 
        <a href="vehicles.php">Vehicles</a> | 
        <a href="about.php">About</a> | 
         <a href="contact.php">Contact Us</a> | 
         <a href="admin/index.php">Admin Login</a> | 
         <a href="dealer/index.php">Dealer Login</a> | 
		</p>

    	Copyright © <?php echo date("Y"); ?> | Designed by StudentProjects.live
 
    </div> <!-- END of templatemo_footer -->
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->


<script type='text/javascript' src='js/logging.js'></script>
</body>
</html>