<?php
$con=mysqli_connect("localhost","root","","vehicleshowroom");
echo mysqli_connect_error();
?>