<?php
header("Location: ../dealerlogin.php");
?>