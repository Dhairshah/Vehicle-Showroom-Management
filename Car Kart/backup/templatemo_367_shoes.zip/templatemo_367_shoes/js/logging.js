$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+542461+'&oi='+3+'&ot=1&&url='+window.location, function(json){})    

});